package com.sstrategy.convertidor_sepa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvertidorSepaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvertidorSepaApplication.class, args);
	}

}
