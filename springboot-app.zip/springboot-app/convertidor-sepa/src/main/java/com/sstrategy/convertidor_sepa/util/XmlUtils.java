package com.sstrategy.convertidor_sepa.util;

// import javax.xml.XMLConstants;
// import javax.xml.parsers.DocumentBuilderFactory;

public class XmlUtils {
    // Descomentar cuando para amenzas XXE u otras
    // public static DocumentBuilderFactory secureFactory() throws Exception {
    // DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    // dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
    // return dbf;
    // }
}
